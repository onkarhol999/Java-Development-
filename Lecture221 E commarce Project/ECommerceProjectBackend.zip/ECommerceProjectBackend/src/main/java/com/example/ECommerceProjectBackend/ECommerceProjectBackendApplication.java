package com.example.ECommerceProjectBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceProjectBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommerceProjectBackendApplication.class, args);
	}

}
