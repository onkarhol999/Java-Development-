package com.example.ECommerceProjectBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceProjectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
