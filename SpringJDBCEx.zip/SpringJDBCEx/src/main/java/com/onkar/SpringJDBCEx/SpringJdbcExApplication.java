package com.onkar.SpringJDBCEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJdbcExApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJdbcExApplication.class, args);
	}

}
