package com.example.spring_data_jpa_ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaExApplicationTests {

	@Test
	void contextLoads() {
	}

}
