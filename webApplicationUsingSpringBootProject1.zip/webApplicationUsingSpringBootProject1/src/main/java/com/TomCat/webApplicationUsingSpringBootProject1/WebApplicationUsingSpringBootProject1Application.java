package com.TomCat.webApplicationUsingSpringBootProject1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebApplicationUsingSpringBootProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(WebApplicationUsingSpringBootProject1Application.class, args);
	}

}
